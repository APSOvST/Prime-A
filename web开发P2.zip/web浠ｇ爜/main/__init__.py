default_app_config = 'main.apps.MainConfig'
